# ==============================================================================
# FLYSHOOT Main Workflow
# ==============================================================================
# Main processing script for flyshoot trip data
# Processes all data types and saves to Parquet format
#
# Aligned with Poseidat system conventions
# ==============================================================================

# Setup ----
options(max.print = 999999)
options(dplyr.summarise.inform = FALSE)

rm(list=ls())

# Load required libraries
library(tidyverse)
library(arrow)
library(readxl)
library(lubridate)
library(sf)
library(glue)
library(jsonlite)
library(here)

# Load configuration
if (!file.exists("config.json")) {
  stop("Configuration not found. Please run 00_setup.R first.")
}

config <- read_json("config.json")

# Load harbour places for port coordinate lookup during vm synthesis
places_file <- file.path(here(), "R", "harmonized", "flyshoot_places.csv")
places_all  <- if (file.exists(places_file)) {
  readr::read_csv(places_file, col_types = "cddcc", show_col_types = FALSE)
} else {
  message("  ⚠ flyshoot_places.csv not found — port coordinates will be NA in vessel_movement")
  tibble::tibble(name = character(), lon = numeric(), lat = numeric(),
                 type = character(), harbour_code = character())
}

lookup_port_coord <- function(port_vec, coord_col) {
  p_up <- toupper(port_vec)
  n_up <- toupper(places_all$name)
  h_up <- if ("harbour_code" %in% names(places_all))
             toupper(places_all$harbour_code) else character(0)
  vapply(p_up, function(p) {
    if (is.na(p)) return(NA_real_)
    idx <- match(p, n_up)
    if (is.na(idx) && length(h_up)) idx <- match(p, h_up)
    if (is.na(idx)) NA_real_ else places_all[[coord_col]][idx]
  }, numeric(1))
}

# Source functions
source(file.path(here(), "R/harmonized", "01_flyshoot_functions.R"))
source(file.path(here(), "R/harmonized", "02_storage_functions.R"))
source(file.path(here(), "R/harmonized", "kisten_haul_assignment.R"))   # auto haul-ID assignment for kisten files

message("\n")
message("=" |> rep(70) |> paste0(collapse = ""), "\n")
message("FLYSHOOT DATA PROCESSING WORKFLOW\n")
message("=" |> rep(70) |> paste0(collapse = ""), "\n\n")

# Load existing data ----
message("Loading existing data from Parquet files...\n")

haul_existing <- tryCatch(
  load_flyshoot_data("haul"),
  error = function(e) {
    message("  No existing haul data found")
    tibble()
  }
)

trip_existing <- tryCatch(
  load_flyshoot_data("trip"),
  error = function(e) {
    message("  No existing trip data found")
    tibble()
  }
)

kisten_existing <- tryCatch(
  load_flyshoot_data("kisten"),
  error = function(e) {
    message("  No existing kisten data found")
    tibble()
  }
)

elog_existing <- tryCatch(
  load_flyshoot_data("elog"),
  error = function(e) {
    message("  No existing elog data found")
    tibble()
  }
)

elog_trek_existing <- tryCatch(
  load_flyshoot_data("elog_trek"),
  error = function(e) {
    message("  No existing elog_trek data found")
    tibble()
  }
)

# Load spatial datasets ----
message("Loading spatial datasets...\n")

spatial_datasets <- list()

# Load FAO areas
fao_path <- file.path(config$spatial_data, "fao_sf.RData")
if (file.exists(fao_path)) {
  load(fao_path)
  spatial_datasets$fao_sf_area <- fao_sf %>% 
    filter(F_LEVEL == "MAJOR") %>%
    select(fao_area = F_AREA)
  spatial_datasets$fao_sf_division <- fao_sf %>%
    filter(F_LEVEL == "DIVISION") %>%
    select(fao_division = F_DIVISION)
  message("  ✓ FAO areas loaded")
} else {
  message("  ⚠ FAO areas not found")
}

# Load ICES rectangles
rect_path <- file.path(config$spatial_data, "rect_sf.RData")
if (file.exists(rect_path)) {
  load(rect_path)
  spatial_datasets$rect_sf <- rect_sf %>%
    select(ices_rect = ICESNAME)
  message("  ✓ ICES rectangles loaded")
} else {
  message("  ⚠ ICES rectangles not found")
}

# Load EEZ
eez_path <- file.path(config$spatial_data, "eez_sf.RData")
if (file.exists(eez_path)) {
  load(eez_path)
  spatial_datasets$eez_sf <- eez_sf %>%
    select(economic_zone = ISO_TER1)
  message("  ✓ EEZ loaded")
} else {
  message("  ⚠ EEZ not found")
}

message("\n")

# Scan for files to process ----
message("Scanning for new trip data files...\n")

file_inventory <- get_file_inventory(
  input_dir = config$tripdata_input,
  file_patterns = config$file_patterns
)

if (nrow(file_inventory) == 0) {
  message("\nExiting.\n")
  # message("=" |> rep(70) |> paste0(collapse = ""), "\n")
  stop("No files to process", call. = FALSE)
}

# Display file inventory
# message("\nFiles to process:")
file_inventory %>%
  select(vessel, trip, source, filename) %>%
  print(n = Inf)

message("\n")

# Group files by vessel and trip ----
trip_groups <- file_inventory %>%
  group_by(vessel, trip) %>%
  summarise(
    n_files = n(),
    sources = list(source),
    files = list(file),
    .groups = "drop"
  )

message(glue("Found {nrow(trip_groups)} trips to process\n\n"))

# Process each trip ----
# message("=" |> rep(70) |> paste0(collapse = ""), "\n")
# message("PROCESSING TRIPS\n")
# message("=" |> rep(70) |> paste0(collapse = ""), "\n\n")
trip_groups %>%
  select(vessel, trip, n_files, sources) %>%
  rowwise() %>%
  mutate(sources = paste(sources, collapse = ", ")) %>%
  ungroup() %>%
  print(n = Inf)



all_new_hauls      <- list()
all_new_trips      <- list()
all_new_kisten     <- list()
all_new_elogs      <- list()
all_new_elog_treks <- list()

i <- 4  # counter for trips
for (i in seq_len(nrow(trip_groups))) {
  
  trip_row  <- trip_groups[i, ]
  vessel_id <- trip_row$vessel
  trip_id   <- trip_row$trip
  sources   <- trip_row$sources[[1]]
  files     <- trip_row$files[[1]]
  
  message(glue("Processing {vessel_id} - Trip {trip_id} ({length(sources)} files)"))
  
  # Create trip files dataframe
  trip_files <- tibble(
    vessel = vessel_id,
    trip = trip_id,
    source = sources,
    file = files
  )
  
  # Detect data source type
  data_source <- detect_data_source_type(trip_files)
  message(glue("  Data source type: {data_source}"))
  
  # Process based on data source type
  trip_hauls      <- NULL
  trip_catches    <- NULL
  trip_info       <- NULL
  trip_elog       <- NULL
  trip_elog_trek  <- NULL
  
  tryCatch({
    
    if (data_source == "treklijst_full") {
      
      # Full manual treklijst
      treklijst_file <- trip_files %>% filter(source == "treklijst") %>% pull(file)
      
      # Get haul information
      trip_hauls <- get_haul_from_treklijst(treklijst_file)
      
      # Extract timezone from haul data to pass to kisten processing
      trip_tz <- if (!is.null(trip_hauls) && "timezone" %in% names(trip_hauls)) {
        first(na.omit(trip_hauls$timezone))
      } else { "Europe/Amsterdam" }
      
      source(file.path(here(), "R/harmonized", "01_flyshoot_functions.R"))
      
      # Check for kisten file — pass treklijst_path for haul_id assignment
      if ("kisten" %in% sources) {
        kisten_file  <- trip_files %>% filter(source == "kisten") %>% pull(file)
        trip_catches <- get_catch_from_kisten(kisten_file, local_tz = trip_tz,
                                              treklijst_path = treklijst_file)
      }
      
      trip_info <- get_trip_info(treklijst_file, haul_data = trip_hauls)           # file_path <- treklijst_file
      
    } else if (data_source == "pefa_trek") {
      
      # PEFA per trek
      pefa_file <- trip_files %>% filter(source == "pefa_trek") %>% pull(file)
      
      # Pass elog_existing so trip_id is looked up from elog rather than
      # constructed from the filename date range (fixes "2026031620260319" bug)
      elog_lookup <- if (nrow(elog_existing) > 0)
        dplyr::select(elog_existing, vessel, date, trip_id) %>% dplyr::distinct()
      else NULL
      
      trip_hauls     <- get_haul_from_pefa_trek(pefa_file, elog_data = elog_lookup)
      trip_elog_trek <- get_catch_from_pefa_trek(pefa_file, elog_data = elog_lookup)
      trip_info      <- get_trip_info(pefa_file)
      
      # Check for kisten file
      if ("kisten" %in% sources) {
        kisten_file <- trip_files %>% filter(source == "kisten") %>% pull(file)
        trip_catches <- get_catch_from_kisten(kisten_file)
      }
      
    # } else if (data_source == "treklijst_simplified") {
    #   # Simplified treklijst + kisten
    #   treklijst_file <- trip_files %>% filter(source == "treklijst") %>% pull(file)
    #   kisten_file <- trip_files %>% filter(source == "kisten") %>% pull(file)
    #   
    #   trip_hauls <- get_haul_from_treklijst(treklijst_file)
    #   trip_tz <- if (!is.null(trip_hauls) && "timezone" %in% names(trip_hauls)) {
    #     first(na.omit(trip_hauls$timezone))
    #   } else { "Europe/Amsterdam" }
    #   trip_catches <- get_catch_from_kisten(kisten_file, local_tz = trip_tz)
    #   trip_info <- get_trip_info(treklijst_file, haul_data = trip_hauls)

    } else if (data_source == "treklijst_simplified") {
      treklijst_file <- trip_files %>% filter(source == "treklijst") %>% pull(file)
      kisten_file    <- trip_files %>% filter(source == "kisten")    %>% pull(file)
      
      trip_hauls   <- get_haul_from_treklijst(treklijst_file)
      local_tz     <- if (!is.null(trip_hauls) && "timezone" %in% names(trip_hauls))
        first(trip_hauls$timezone) else "Europe/Amsterdam"
      
      # Pass treklijst path so get_catch_from_kisten() can auto-assign haul IDs
      trip_catches <- get_catch_from_kisten(kisten_file,
                                            local_tz       = local_tz,
                                            treklijst_path = treklijst_file)
      trip_info    <- get_trip_info(treklijst_file)
      
    } else if (data_source == "kisten_pefa") {

      pefa_file   <- trip_files %>% filter(source == "pefa")   %>% pull(file)
      kisten_file <- trip_files %>% filter(source == "kisten") %>% pull(file)
      
      trip_hauls <- get_haul_from_kisten_pefa(pefa_file, kisten_file)
      
      # If a treklijst is also present for this trip, use it for haul assignment
      trek_file <- if ("treklijst" %in% trip_files$source)
        trip_files %>% filter(source == "treklijst") %>% pull(file)
      else NULL
      
      trip_catches <- get_catch_from_kisten(kisten_file,
                                            treklijst_path = trek_file)
      trip_info    <- get_trip_info(pefa_file)
      
      if ("elog" %in% sources) {
        elog_file <- trip_files %>% filter(source == "elog") %>% pull(file)
        elog_result <- get_data_from_elog(elog_file)
        trip_info   <- elog_result$trip
      }
      
      # # Kisten + PEFA positions
      # pefa_file <- trip_files %>% filter(source == "pefa") %>% pull(file)
      # kisten_file <- trip_files %>% filter(source == "kisten") %>% pull(file)
      # 
      # trip_hauls <- get_haul_from_kisten_pefa(pefa_file, kisten_file)
      # trip_catches <- get_catch_from_kisten(kisten_file)
      # trip_info <- get_trip_info(pefa_file)
      # 
      # # Supplement trip info from elog if available
      # if ("elog" %in% sources) {
      #   elog_file <- trip_files %>% filter(source == "elog") %>% pull(file)
      #   elog_result <- get_data_from_elog(elog_file)
      #   trip_info <- elog_result$trip
      # }
      
    } else if (data_source == "elog_only") {
      # Elog only — catch and trip info from elog
      elog_file <- trip_files %>% filter(source == "elog") %>% pull(file)
      elog_result <- get_data_from_elog(elog_file)
      trip_elog <- elog_result$catch
      trip_info <- elog_result$trip
      message("  ⚠ No haul position data available (elog only)")
      
    } else if (data_source == "elog_by_haul") {
      # Elog + elog_by_haul (per-haul catch detail) — no treklijst or kisten
      elog_file         <- trip_files %>% filter(source == "elog") %>% pull(file)
      elog_by_haul_file <- trip_files %>% filter(source == "elog_trek") %>% pull(file)
      
      elog_result       <- get_data_from_elog(elog_file)
      trip_info         <- elog_result$trip
      trip_elog         <- elog_result$catch
      
      # elog_by_haul provides per-haul detail; reader to be implemented
      message("  ℹ elog_by_haul reader not yet implemented — using elog summary only")
      
    } else if (data_source == "kisten_only") {
      # Kisten only - limited processing
      kisten_file <- trip_files %>% filter(source == "kisten") %>% pull(file)
      
      trip_catches <- get_catch_from_kisten(kisten_file)
      trip_info <- get_trip_info(kisten_file)
      
      message("  ⚠ No position data available (kisten only)")
      
    } else {
      message(glue("  ⚠ Unsupported data source: {data_source}"))
    }
    
    # ------------------------------------------------------------------
    # Read elog independently, regardless of primary data source type.
    # Elog is always appended to elog_existing when present.
    # ------------------------------------------------------------------
    if ("pefa" %in% sources && is.null(trip_elog)) {
      tryCatch({
        elog_file   <- trip_files %>% filter(source == "pefa") %>% pull(file)
        elog_result <- get_data_from_elog(elog_file)
        trip_elog   <- elog_result$catch
        # Supplement trip_info with elog trip data if not already set
        if (is.null(trip_info) || nrow(trip_info) == 0) {
          trip_info <- elog_result$trip
        }
        message(glue("  ✓ Elog: {nrow(trip_elog)} catch records"))
      }, error = function(e) {
        message(glue("  ✗ Could not read elog: {e$message}"))
      })
    }
    
    # Add spatial attributes to hauls
    if (!is.null(trip_hauls) && nrow(trip_hauls) > 0) {
      if (config$add_spatial_data && length(spatial_datasets) > 0) {
        trip_hauls <- add_spatial_attributes(trip_hauls, spatial_datasets)
      }
      
      # Validate haul data
      if (config$validate_data) {
        validation <- validate_haul_data(trip_hauls)
      }
      
      message(glue("  ✓ Processed {nrow(trip_hauls)} hauls"))
    }
    
    # Process catches
    if (!is.null(trip_catches) && nrow(trip_catches) > 0) {
      # Standardize species codes
      trip_catches <- trip_catches %>%
        mutate(species_code = standardize_species_codes(species_code))
      
      message(glue("  ✓ Processed {nrow(trip_catches)} catch records"))
    }
    
    message("  ✓ Trip processing complete\n")
    
  }, error = function(e) {
    message(glue("  ✗ Error processing trip: {e$message}\n"))
  })

  # Store processed data OUTSIDE tryCatch so partial results are never lost.
  # Even if spatial attributes or validation fails, collected data is saved.
  if (!is.null(trip_hauls) && nrow(trip_hauls) > 0) {
    all_new_hauls[[length(all_new_hauls) + 1]] <- trip_hauls
  }
  if (!is.null(trip_info) && nrow(trip_info) > 0) {
    all_new_trips[[length(all_new_trips) + 1]] <- trip_info
  }
  if (!is.null(trip_catches) && nrow(trip_catches) > 0) {
    all_new_kisten[[length(all_new_kisten) + 1]] <- trip_catches
  }
  if (!is.null(trip_elog) && nrow(trip_elog) > 0) {
    all_new_elogs[[length(all_new_elogs) + 1]] <- trip_elog
  }
  if (!is.null(trip_elog_trek) && nrow(trip_elog_trek) > 0) {
    all_new_elog_treks[[length(all_new_elog_treks) + 1]] <- trip_elog_trek
  }
  
}

# Combine all new data ----
# Strategy: for each data type, REMOVE all existing records that belong to
# trips being reprocessed, then APPEND the new records. This ensures updated
# data always replaces old data rather than being silently deduplicated away.
message("\n")
message("=" |> rep(70) |> paste0(collapse = ""), "\n")
message("SAVING PROCESSED DATA\n")
message("=" |> rep(70) |> paste0(collapse = ""), "\n\n")

# Build a lookup of all vessel+trip combinations that were processed this run
processed_trips <- file_inventory %>%
  distinct(vessel, trip) %>%
  rename(trip_id = trip)

# Helper: safely remove processed trips from an existing dataset.
# Returns list(cleaned = tibble, n_removed = integer).
# Handles the case where existing is empty or lacks the join columns
# (e.g. first run, no parquet file yet).
safe_remove_trips <- function(existing, trips_lookup, new_data = NULL) {
  if (nrow(existing) == 0 ||
      !all(c("vessel", "trip_id") %in% names(existing))) {
    return(list(cleaned = existing, n_removed = 0L))
  }
  cleaned <- dplyr::anti_join(existing, trips_lookup, by = c("vessel", "trip_id"))
  # Secondary: remove stale records by date range (catches mismatched trip_ids)
  if (!is.null(new_data) && nrow(new_data) > 0 &&
      all(c("vessel", "date") %in% names(new_data)) &&
      "date" %in% names(cleaned)) {
    date_ranges <- new_data %>%
      dplyr::group_by(vessel) %>%
      dplyr::summarise(date_min = min(date, na.rm = TRUE),
                       date_max = max(date, na.rm = TRUE), .groups = "drop")
    stale <- cleaned %>%
      dplyr::inner_join(date_ranges, by = "vessel") %>%
      dplyr::filter(date >= date_min & date <= date_max) %>%
      dplyr::select(vessel, trip_id) %>% dplyr::distinct()
    if (nrow(stale) > 0) {
      message(glue("  Removing {nrow(stale)} stale trip_id(s): ",
                   "{paste(unique(stale$trip_id), collapse=', ')}"))
      cleaned <- dplyr::anti_join(cleaned, stale, by = c("vessel", "trip_id"))
    }
  }
  list(cleaned = cleaned, n_removed = nrow(existing) - nrow(cleaned))
}

# Helper: reconcile column types between existing and new data before bind_rows.
# When the existing parquet was converted from RData, some columns may be stored
# as character that the new pipeline produces as integer/double, causing
# "Can't combine" errors. This coerces shared columns to the new data's types.
reconcile_types <- function(existing, new_data) {
  if (nrow(existing) == 0) return(existing)
  shared <- intersect(names(existing), names(new_data))
  for (col in shared) {
    type_new <- class(new_data[[col]])[1]
    type_old <- class(existing[[col]])[1]
    if (type_new != type_old) {
      existing[[col]] <- tryCatch(
        switch(type_new,
               "integer"   = as.integer(suppressWarnings(as.numeric(existing[[col]]))),
               "numeric"   = suppressWarnings(as.numeric(existing[[col]])),
               "double"    = suppressWarnings(as.numeric(existing[[col]])),
               "character" = as.character(existing[[col]]),
               "logical"   = as.logical(existing[[col]]),
               "Date"      = as.Date(existing[[col]]),
               "POSIXct"   = as.POSIXct(existing[[col]], tz = "UTC"),
               existing[[col]]   # fallback: leave unchanged
        ),
        error = function(e) {
          message(glue("  ⚠ Could not reconcile type for '{col}': {type_old} -> {type_new}"))
          existing[[col]]
        }
      )
    }
  }
  existing
}

# Synthesise vessel_movement entirely from haul data
# departure_port/arrival_port/dates come from the haul worksheet itself
all_new_vm <- list()
for (i in seq_along(all_new_hauls)) {
  h_i <- all_new_hauls[[i]]
  if (nrow(h_i) == 0) next

  trip_nr_val <- if ("trip_nr" %in% names(h_i)) dplyr::first(na.omit(h_i$trip_nr)) else NA_character_

  # Haul events from shoot positions
  vm_hauls <- h_i %>%
    dplyr::filter(!is.na(shoot_lat), !is.na(shoot_lon)) %>%
    dplyr::transmute(
      vessel, trip_id,
      trip_nr    = trip_nr_val,
      date       = as.Date(dplyr::coalesce(shoot_time, as.POSIXct(date))),
      event_type = "haul", haul_id = haul_id,
      port = NA_character_, lat = shoot_lat, lon = shoot_lon,
      distance = NA_real_, source = "treklijst")

  # Departure and arrival derived from haul columns
  dep_port  <- dplyr::first(na.omit(h_i$departure_port))
  dep_date  <- dplyr::first(na.omit(h_i$departure_date))
  arr_port  <- dplyr::first(na.omit(h_i$arrival_port))
  arr_date  <- dplyr::first(na.omit(h_i$arrival_date))
  vessel_id <- dplyr::first(h_i$vessel)
  trip_id_v <- dplyr::first(h_i$trip_id)

  vm_ports <- dplyr::bind_rows(
    if (!is.na(dep_date))
      tibble::tibble(vessel = vessel_id, trip_id = trip_id_v,
                     trip_nr = trip_nr_val,
                     date = as.Date(dep_date), event_type = "departure",
                     haul_id = NA_integer_, port = dep_port,
                     lat = lookup_port_coord(dep_port, "lat"),
                     lon = lookup_port_coord(dep_port, "lon"),
                     distance = NA_real_, source = "treklijst")
    else tibble::tibble(),
    if (!is.na(arr_date))
      tibble::tibble(vessel = vessel_id, trip_id = trip_id_v,
                     trip_nr = trip_nr_val,
                     date = as.Date(arr_date), event_type = "arrival",
                     haul_id = NA_integer_, port = arr_port,
                     lat = lookup_port_coord(arr_port, "lat"),
                     lon = lookup_port_coord(arr_port, "lon"),
                     distance = NA_real_, source = "treklijst")
    else tibble::tibble()
  )

  vm_i <- dplyr::bind_rows(vm_ports, vm_hauls) %>% dplyr::arrange(date)
  if (nrow(vm_i) > 0) all_new_vm[[length(all_new_vm) + 1]] <- vm_i
}
if (length(all_new_vm) > 0) {
  vm_existing <- tryCatch(load_flyshoot_data("vessel_movement"), error = function(e) tibble::tibble())
  new_vm <- dplyr::bind_rows(all_new_vm)
  r_vm   <- safe_remove_trips(vm_existing, processed_trips, new_data = new_vm)
  combined_vm <- reconcile_types(r_vm$cleaned, new_vm) %>%
    dplyr::bind_rows(new_vm) %>% dplyr::arrange(vessel, trip_id, date)
  save_flyshoot_data(combined_vm, "vessel_movement",
    date_range = c(min(combined_vm$date, na.rm=TRUE), max(combined_vm$date, na.rm=TRUE)))
  message(glue("  Vessel movement: {nrow(new_vm)} synthetic events added"))
}

if (length(all_new_hauls) > 0) {
  new_hauls <- bind_rows(all_new_hauls)
  r         <- safe_remove_trips(haul_existing, processed_trips)
  combined_hauls <- reconcile_types(r$cleaned, new_hauls) %>%
    bind_rows(new_hauls) %>%
    arrange(vessel, trip_id, haul_id)
  save_flyshoot_data(combined_hauls, "haul",
    date_range = c(min(combined_hauls$date, na.rm = TRUE),
                   max(combined_hauls$date, na.rm = TRUE)))
  message(glue("  Hauls: removed {r$n_removed} old records, ",
               "added {nrow(new_hauls)} new (total: {nrow(combined_hauls)})"))
}

if (length(all_new_trips) > 0) {
  new_trips <- bind_rows(all_new_trips)
  r         <- safe_remove_trips(trip_existing, processed_trips)
  combined_trips <- reconcile_types(r$cleaned, new_trips) %>%
    bind_rows(new_trips) %>%
    arrange(vessel, trip_id)
  save_flyshoot_data(combined_trips, "trip",
    date_range = c(min(combined_trips$departure_date, na.rm = TRUE),
                   max(combined_trips$arrival_date, na.rm = TRUE)))
  message(glue("  Trips: removed {r$n_removed} old records, ",
               "added {nrow(new_trips)} new (total: {nrow(combined_trips)})"))
}

if (length(all_new_kisten) > 0) {
  new_kisten <- bind_rows(all_new_kisten)
  r          <- safe_remove_trips(kisten_existing, processed_trips)
  combined_kisten <- reconcile_types(r$cleaned, new_kisten) %>%
    bind_rows(new_kisten) %>%
    arrange(vessel, trip_id, haul_id, species_code)
  save_flyshoot_data(combined_kisten, "kisten",
    date_range = c(min(combined_kisten$date, na.rm = TRUE),
                   max(combined_kisten$date, na.rm = TRUE)))
  message(glue("  Kisten: removed {r$n_removed} old records, ",
               "added {nrow(new_kisten)} new (total: {nrow(combined_kisten)})"))
}

if (length(all_new_elogs) > 0) {
  new_elogs <- bind_rows(all_new_elogs)
  r         <- safe_remove_trips(elog_existing, processed_trips)
  
  # Schema compatibility check: only warn if new data has columns not in existing
  if (nrow(r$cleaned) > 0) {
    new_only <- setdiff(names(new_elogs), names(r$cleaned))
    if (length(new_only) > 0) {
      warning(glue(
        "Elog schema mismatch: new data has columns not in existing parquet:\n",
        "  {paste(new_only, collapse=', ')}\n",
        "  Run migrate_elog_schema.R to align the existing data."
      ))
    }
  }
  
  combined_elogs <- reconcile_types(r$cleaned, new_elogs) %>%
    bind_rows(new_elogs) %>%
    arrange(vessel, trip_id, date, species_code)
  save_flyshoot_data(combined_elogs, "elog",
    date_range = c(min(combined_elogs$date, na.rm = TRUE),
                   max(combined_elogs$date, na.rm = TRUE)))
  message(glue("  Elog: removed {r$n_removed} old records, ",
               "added {nrow(new_elogs)} new (total: {nrow(combined_elogs)})"))
}

if (length(all_new_elog_treks) > 0) {
  new_elog_treks <- bind_rows(all_new_elog_treks)
  r              <- safe_remove_trips(elog_trek_existing, processed_trips)
  combined_elog_treks <- reconcile_types(r$cleaned, new_elog_treks) %>%
    bind_rows(new_elog_treks) %>%
    arrange(vessel, trip_id, haul_id, species_code)
  save_flyshoot_data(combined_elog_treks, "elog_trek",
    date_range = c(min(combined_elog_treks$date, na.rm = TRUE),
                   max(combined_elog_treks$date, na.rm = TRUE)))
  message(glue("  Elog_trek: removed {r$n_removed} old records, ",
               "added {nrow(new_elog_treks)} new (total: {nrow(combined_elog_treks)})"))
}

# ==============================================================================
# MOVE FILES
# ==============================================================================

move_files <- FALSE   # set TRUE to run, FALSE to skip

if (move_files && nrow(processed_trips) > 0) {
  
  message("\n")
  message("Moving processed files to archive folder...\n")
  
  processed_dir <- config$tripdata_processed
  
  for (file_path in file_inventory$file) {
    dest_path <- file.path(processed_dir, basename(file_path))
    
    tryCatch({
      file.copy(file_path, dest_path, overwrite = TRUE)
      file.remove(file_path)
      message(glue("  ✓ Moved: {basename(file_path)}"))
    }, error = function(e) {
      message(glue("  ✗ Failed to move: {basename(file_path)}"))
    })
  }
  
}



# ==============================================================================
# Create summary report ----
# ==============================================================================

message("\n")
message("=" |> rep(70) |> paste0(collapse = ""), "\n")
message("PROCESSING SUMMARY\n")
message("=" |> rep(70) |> paste0(collapse = ""), "\n\n")

message(glue("Files processed: {nrow(file_inventory)}"))
message(glue("Trips processed: {nrow(trip_groups)}"))

if (length(all_new_hauls) > 0) {
  message(glue("New hauls: {nrow(bind_rows(all_new_hauls))}"))
}
if (length(all_new_trips) > 0) {
  message(glue("New trips: {nrow(bind_rows(all_new_trips))}"))
}
if (length(all_new_kisten) > 0) {
  message(glue("New catch records (kisten): {nrow(bind_rows(all_new_kisten))}"))
}
if (length(all_new_elogs) > 0) {
  message(glue("New elog records: {nrow(bind_rows(all_new_elogs))}"))
}
if (length(all_new_elog_treks) > 0) {
  message(glue("New elog_trek records: {nrow(bind_rows(all_new_elog_treks))}"))
}

message("\n")

# Show storage statistics
get_storage_stats()

message("=" |> rep(70) |> paste0(collapse = ""), "\n")
message("PROCESSING COMPLETE\n")
message("=" |> rep(70) |> paste0(collapse = ""), "\n\n")

message("Next steps:")
message("  - Review processed data in Parquet files")
message("  - Create trip summaries: create_trip_summary()")
message("  - View storage stats: get_storage_stats()")
message("  - Load data for analysis: load_flyshoot_data('haul')\n")

# ==============================================================================
# AUTO-RENDER TRIPREPORTS FOR NEWLY PROCESSED TRIPS
# ==============================================================================
# After parquet files are written, render a tripreport for each vessel/trip
# that was successfully processed in this run.
#
# The date range for each report is derived from the actual data just saved,
# not from a manual date specification — so no extra configuration is needed.
#
# Set render_reports <- FALSE to skip report generation entirely.
# ==============================================================================

render_reports <- TRUE   # set FALSE to skip

if (render_reports && nrow(processed_trips) > 0) {

  rmd_file <- file.path(here(), "R", "harmonized", "FLYSHOOT_tripreport_harmonized.Rmd")

  if (!file.exists(rmd_file)) {
    message("⚠ Tripreport Rmd not found — skipping report generation:")
    message(glue("    {rmd_file}"))

  } else {

    message(strrep("=", 50), "\n")
    message("AUTO-RENDERING TRIPREPORTS\n")
    message(strrep("=", 50), "\n")
    
    # Load storage functions if not already loaded (idempotent)
    if (!exists("load_flyshoot_data")) {
      source(file.path(here(), "R", "harmonized", "02_storage_functions.R"))
    }

    # Build per-vessel date ranges from the data just written to parquet.
    # We prefer elog (most complete date coverage), then haul, then kisten.
    # This reuses the parquet we just wrote so there is no re-reading of
    # raw files and the date range always matches exactly what was processed.
    derive_trip_dates <- function(vessel_id, trip_id_chr) {
      for (type in c("elog", "haul", "kisten")) {
        dat <- tryCatch(
          suppressMessages(load_flyshoot_data(type, vessel_ids = vessel_id)),
          error = function(e) tibble()
        )
        if (nrow(dat) == 0 || !"date" %in% names(dat) || !"trip_id" %in% names(dat)) next

        # Exact match first
        filtered <- dplyr::filter(dat, vessel == vessel_id, trip_id == trip_id_chr)

        # If no exact match, try partial: trip_id_chr may be a date-range string
        # (e.g. "2026031620260319") while the parquet stores the trip nr differently.
        # Fall back to matching rows whose date range overlaps the trip_id_chr dates.
        if (nrow(filtered) == 0 && nchar(trip_id_chr) == 16 &&
            grepl("^[0-9]{16}$", trip_id_chr)) {
          start_try <- tryCatch(as.Date(substr(trip_id_chr, 1, 8), "%Y%m%d"), error = function(e) NA)
          end_try   <- tryCatch(as.Date(substr(trip_id_chr, 9, 16), "%Y%m%d"), error = function(e) NA)
          if (!is.na(start_try) && !is.na(end_try)) {
            filtered <- dplyr::filter(dat,
                                      vessel == vessel_id,
                                      date   >= start_try,
                                      date   <= end_try)
            if (nrow(filtered) > 0) {
              # Report which trip_ids were actually found
              found_ids <- paste(sort(unique(filtered$trip_id)), collapse = ", ")
              # message(glue("    {type}: {nrow(filtered)} records for {vessel_id} by date range",
              #              " (trip_ids in parquet: {found_ids})"))
            }
          }
        } else if (nrow(filtered) > 0) {
          # message(glue("    {type}: {nrow(filtered)} records for {vessel_id} / {trip_id_chr}"))
        }

        if (nrow(filtered) > 0) {
          return(list(
            startdate = min(filtered$date, na.rm = TRUE),
            enddate   = max(filtered$date, na.rm = TRUE)
          ))
        }
      }
      NULL   # no date range found — report will be skipped
    }

    # Render one report; returns a one-row tibble with status info
    render_one_report <- function(vessel_id, trip_id_chr, lang = "nl") {

      dates <- derive_trip_dates(vessel_id, trip_id_chr)

      if (is.null(dates)) {
        message(glue("  ⊘ {vessel_id} / {trip_id_chr} — no date range found, skipping"))
        return(tibble(vessel = vessel_id, trip_id = trip_id_chr,
                      status = "skipped", reason = "no date range", path = NA_character_,
                      elapsed = NA_real_, size_kb = NA_real_))
      }

      startdate <- dates$startdate
      enddate   <- dates$enddate

      # Build output filename in the same convention as batch_render_tripreports.R
      yr   <- lubridate::year(startdate)
      wk   <- lubridate::isoweek(startdate)
      output_filename <- glue(
        "{vessel_id}_{yr}W{sprintf('%02d', wk)}_trip{trip_id_chr}.docx"
      )

      output_dir  <- file.path(config$tripdata, vessel_id)
      if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
      output_path <- file.path(output_dir, output_filename)

      # Abort gracefully if Word has the file locked; otherwise delete for clean overwrite
      if (file.exists(output_path)) {
        locked <- tryCatch(
          { con <- file(output_path, open = "ab"); close(con); FALSE },
          error = function(e) TRUE
        )
        if (locked) {
          message(glue("  ✗ {vessel_id} / {trip_id_chr} — file open in Word: {output_filename}"))
          return(tibble(vessel = vessel_id, trip_id = trip_id_chr,
                        status = "error", reason = "file locked by Word",
                        path = NA_character_, elapsed = NA_real_, size_kb = NA_real_))
        }
        file.remove(output_path)
      }

      # message(glue("  Rendering: {output_filename}"))
      # message(glue("    {format(startdate, '%d/%m/%Y')} – {format(enddate, '%d/%m/%Y')}"))
      message(glue("  Rendering: {output_filename} / {format(startdate, '%d/%m/%Y')} – {format(enddate, '%d/%m/%Y')}"))

      t0 <- Sys.time()

      options(
        flyshoot.vessel      = vessel_id,
        flyshoot.startdate   = startdate,
        flyshoot.enddate     = enddate,
        flyshoot.lang        = lang,
        flyshoot.max_species = 12
      )

      tryCatch(
        rmarkdown::render(input = rmd_file, output_file = output_path, quiet = TRUE),
        error = function(e) {
          if (!file.exists(output_path)) stop(e$message)
          message(paste0("  ⚠ Render warning (file still created): ", e$message))
        }
      )

      elapsed   <- round(as.numeric(difftime(Sys.time(), t0, units = "secs")), 1)
      file_size <- if (file.exists(output_path))
        round(file.info(output_path)$size / 1024, 1) else NA_real_
      status    <- if (file.exists(output_path)) "success" else "error"

      message(glue("  {ifelse(status=='success','✓','✗')} {output_filename}",
                   " ({elapsed}s, {file_size} KB)"))

      result <- tibble(vessel = vessel_id, trip_id = trip_id_chr, status = status,
                       reason = NA_character_, path = output_path,
                       elapsed = elapsed, size_kb = file_size)

      result
    }

    # Render for every vessel/trip processed in this run
    report_results <- vector("list", nrow(processed_trips))
    for (i in seq_len(nrow(processed_trips))) {
      report_results[[i]] <- render_one_report(
        processed_trips$vessel[[i]],
        processed_trips$trip_id[[i]]
      )
    }
    report_results <- dplyr::bind_rows(report_results)

    # Summary
    # message("\n", strrep("=", 50))
    # message("TRIPREPORT SUMMARY")
    # message(strrep("=", 50))
    # 
    # message(glue("  ✓ Rendered:  {sum(report_results$status == 'success')}"))
    # message(glue("  ⊘ Skipped:   {sum(report_results$status == 'skipped')}"))
    # message(glue("  ✗ Errors:    {sum(report_results$status == 'error')}"))

    if (any(report_results$status == "success")) {
      message("\nReports written to:")
      success_paths <- report_results %>%
        dplyr::filter(status == "success") %>%
        dplyr::pull(path)
      for (p in success_paths) message(glue("  {p}"))
    }

    if (any(report_results$status == "error")) {
      message("\nErrors:")
      report_results %>%
        dplyr::filter(status == "error") %>%
        dplyr::rowwise() %>%
        dplyr::mutate(.msg = glue("  {vessel}/{trip_id}: {reason}")) %>%
        dplyr::ungroup() %>%
        dplyr::pull(.msg) %>%
        { for (msg in .) message(msg) }
    }

    message("\n")
  }
}
