# ==========================================================================================================
# Batch Render FLYSHOOT Tripreports — multiple vessels
#
# Updated March 2026: data loading from Parquet files via arrow
#
# Output structure: reports/YYYY/WWW/FLYSHOOT_VESSEL_YYYYWWW_Ntrips.docx
# ==========================================================================================================

library(rmarkdown)
library(tidyverse)
library(lubridate)
library(arrow)
library(glue)

source("r/FLYSHOOT utils.R")

# ==========================================================================================================
# CONFIGURATION
# ==========================================================================================================

vessels         <- c("SCH135", "SCH144", "SCH65", "SL9")
startdate       <- dmy("01/12/2025")
enddate         <- dmy("07/12/2025")

# Alternatively, auto-compute last week:
# enddate   <- Sys.Date()
# startdate <- enddate - days(7)

output_base_dir <- "reports"
rmd_file        <- "FLYSHOOT_tripreport_harmonized.Rmd"
open_reports    <- FALSE   # Open each report after render (Windows only)
quiet_mode      <- TRUE    # Suppress rmarkdown rendering messages

# ==========================================================================================================
# RESOLVE PARQUET ROOT
# ==========================================================================================================

flyshoot_root <- Sys.getenv("ONEDRIVE_FLYSHOOT")

if (flyshoot_root == "") {
  user_home     <- Sys.getenv("USERPROFILE")
  if (user_home == "") user_home <- Sys.getenv("HOME")
  flyshoot_root <- file.path(user_home, "Martin Pastoors", "FLYSHOOT - General", "rdata")
  message(glue("ONEDRIVE_FLYSHOOT not set — using fallback: {flyshoot_root}"))
}

# ==========================================================================================================
# LOAD ELOG ONCE — shared across all vessels
# ==========================================================================================================

cat("==========================================\n")
cat("BATCH RENDER FLYSHOOT TRIPREPORTS\n")
cat("==========================================\n")
cat(glue("Date range:  {format(startdate, '%d/%m/%Y')} to {format(enddate, '%d/%m/%Y')}\n"))
cat(glue("Vessels:     {paste(vessels, collapse=', ')}\n"))
cat(glue("Parquet root:{flyshoot_root}\n"))
cat("==========================================\n\n")

cat("Loading elog data...\n")

elog_path <- file.path(flyshoot_root, "elog", "elog.parquet")

if (!file.exists(elog_path)) {
  stop(glue("Elog parquet file not found: {elog_path}"))
}

elog <- arrow::read_parquet(elog_path)

# Validate expected columns
required_cols <- c("vessel", "trip_id", "date")
missing_cols  <- setdiff(required_cols, names(elog))
if (length(missing_cols) > 0) {
  stop(glue("Elog parquet missing expected columns: {paste(missing_cols, collapse=', ')}"))
}

cat(glue("Elog loaded: {nrow(elog)} rows, {n_distinct(elog$vessel)} vessel(s)\n\n"))

# ==========================================================================================================
# FUNCTION: render one vessel report
# ==========================================================================================================

render_vessel_report <- function(vessel_name, start_date, end_date) {

  cat(glue("Processing {vessel_name}...\n"))

  # Resolve trip IDs from pre-loaded elog
  trip_info <- elog %>%
    filter(vessel == vessel_name,
           date >= start_date,
           date <= end_date) %>%
    summarise(
      trips     = paste(sort(unique(trip_id)), collapse = "_"),
      ntrips    = n_distinct(trip_id),
      year      = year(min(date, na.rm = TRUE)),
      week      = isoweek(min(date, na.rm = TRUE)),
      startdate = min(date, na.rm = TRUE),
      enddate   = max(date, na.rm = TRUE),
      .groups   = "drop"
    )

  if (trip_info$ntrips == 0) {
    cat(glue("  ⊘ No trips found for {vessel_name} — skipping\n\n"))
    return(list(vessel = vessel_name, status = "skipped",
                reason = "No trips found", path = NA_character_))
  }

  cat(glue("  Found {trip_info$ntrips} trip(s), ISO week {trip_info$week}: {trip_info$trips}\n"))

  output_filename <- glue(
    "FLYSHOOT_{vessel_name}_{trip_info$year}W{sprintf('%02d', trip_info$week)}_",
    "{trip_info$ntrips}trip{ifelse(trip_info$ntrips > 1, 's', '')}.docx"
  )

  output_dir <- file.path(
    output_base_dir,
    as.character(trip_info$year),
    sprintf("W%02d", trip_info$week)
  )

  if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

  output_path <- file.path(output_dir, output_filename)
  cat(glue("  Rendering: {output_filename}\n"))

  start_time <- Sys.time()

  result <- tryCatch({

    rmarkdown::render(
      input       = rmd_file,
      output_file = output_path,
      params      = list(
        vessel    = vessel_name,
        startdate = start_date,
        enddate   = end_date
      ),
      quiet = quiet_mode,
      envir = new.env()
    )

    elapsed   <- round(as.numeric(difftime(Sys.time(), start_time, units = "secs")), 1)
    file_size <- round(file.info(output_path)$size / 1024, 1)

    cat(glue("  ✓ Done ({elapsed}s, {file_size} KB)\n\n"))

    if (open_reports && .Platform$OS.type == "windows") shell.exec(output_path)

    list(vessel = vessel_name, status = "success", path = output_path,
         trips = trip_info$ntrips, trip_ids = trip_info$trips,
         elapsed = elapsed, size_kb = file_size)

  }, error = function(e) {
    cat(glue("  ✗ Error: {e$message}\n\n"))
    list(vessel = vessel_name, status = "error", reason = e$message,
         path = NA_character_)
  })

  result
}

# ==========================================================================================================
# PROCESS ALL VESSELS
# ==========================================================================================================

cat("Starting batch processing...\n")
cat("------------------------------------------\n\n")

overall_start <- Sys.time()

results <- purrr::map(vessels, ~render_vessel_report(.x, startdate, enddate))

overall_elapsed <- round(as.numeric(difftime(Sys.time(), overall_start, units = "secs")), 1)

# ==========================================================================================================
# SUMMARY
# ==========================================================================================================

cat("\n==========================================\n")
cat("BATCH PROCESSING SUMMARY\n")
cat("==========================================\n\n")

results_df <- purrr::map_dfr(results, ~as_tibble(.) %>%
                                dplyr::select(vessel, status,
                                              any_of(c("trip_ids", "trips", "elapsed",
                                                       "size_kb", "path", "reason"))))

n_success <- sum(results_df$status == "success", na.rm = TRUE)
n_skipped <- sum(results_df$status == "skipped", na.rm = TRUE)
n_errors  <- sum(results_df$status == "error",   na.rm = TRUE)

cat(glue("Vessels processed:  {length(vessels)}\n"))
cat(glue("  ✓ Successful:     {n_success}\n"))
cat(glue("  ⊘ Skipped:        {n_skipped}\n"))
cat(glue("  ✗ Errors:         {n_errors}\n"))
cat(glue("Total time:         {overall_elapsed}s\n"))

if (n_success > 0) {
  avg_time   <- mean(results_df$elapsed[results_df$status == "success"], na.rm = TRUE)
  total_size <- sum(results_df$size_kb[results_df$status == "success"],  na.rm = TRUE)
  cat(glue("Avg render time:    {round(avg_time, 1)}s\n"))
  cat(glue("Total output size:  {round(total_size, 1)} KB\n"))
}

cat("\n------------------------------------------\n")
cat("DETAILED RESULTS\n")
cat("------------------------------------------\n\n")

results_df %>%
  dplyr::mutate(file = ifelse(is.na(path), "-", basename(path))) %>%
  dplyr::select(vessel, status, any_of(c("trip_ids", "trips")), file,
                any_of(c("elapsed", "size_kb", "reason"))) %>%
  knitr::kable(format = "simple") %>%
  print()

if (n_success > 0) {
  cat("\n------------------------------------------\n")
  cat("GENERATED REPORTS\n")
  cat("------------------------------------------\n\n")
  results_df %>%
    dplyr::filter(status == "success") %>%
    dplyr::pull(path) %>%
    purrr::walk(~cat(glue("  {.x}\n")))
}

if (n_errors > 0) {
  cat("\n------------------------------------------\n")
  cat("ERRORS\n")
  cat("------------------------------------------\n\n")
  results_df %>%
    dplyr::filter(status == "error") %>%
    dplyr::select(vessel, reason) %>%
    purrr::pwalk(~cat(glue("  {..1}: {..2}\n")))
}

cat("\n==========================================\n")
cat("Batch processing complete!\n")
cat("==========================================\n")

invisible(results_df)
