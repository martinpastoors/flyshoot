# ==========================================================================================================
# Render FLYSHOOT Tripreport — single vessel
#
# Updated March 2026: data loading from Parquet files via arrow
#
# Output structure: reports/YYYY/WWW/FLYSHOOT_VESSEL_YYYYWWW_Ntrips.docx
# ==========================================================================================================

library(rmarkdown)
library(tidyverse)
library(lubridate)
library(arrow)
library(glue)

# Source utility functions (get_onedrive / theme_publication / lowcase etc.)
source("r/FLYSHOOT utils.R")

# ==========================================================================================================
# CONFIGURATION
# ==========================================================================================================

setvessel <- "SCH135"
startdate <- dmy("01/12/2025")
enddate   <- dmy("04/12/2025")

output_base_dir <- "reports"
rmd_file        <- "FLYSHOOT_tripreport_harmonized.Rmd"

# ==========================================================================================================
# RESOLVE PARQUET ROOT
# ==========================================================================================================
# Reads from ONEDRIVE_FLYSHOOT environment variable (set in .Renviron).
# Falls back to the conventional OneDrive path used by 02_storage_functions.R.

flyshoot_root <- Sys.getenv("ONEDRIVE_FLYSHOOT")

if (flyshoot_root == "") {
  user_home     <- Sys.getenv("USERPROFILE")
  if (user_home == "") user_home <- Sys.getenv("HOME")
  flyshoot_root <- file.path(user_home, "Martin Pastoors", "FLYSHOOT - General", "rdata")
  message(glue("ONEDRIVE_FLYSHOOT not set — using fallback: {flyshoot_root}"))
}

# ==========================================================================================================
# LOAD ELOG TO DETERMINE TRIP DETAILS FOR FILENAME
# ==========================================================================================================

cat("Loading elog data to determine trip details...\n")

elog_path <- file.path(flyshoot_root, "elog", "elog.parquet")

if (!file.exists(elog_path)) {
  stop(glue("Elog parquet file not found: {elog_path}\n",
            "Make sure 03_main_workflow.R has been run and ONEDRIVE_FLYSHOOT is set correctly."))
}

elog <- arrow::read_parquet(elog_path)

# Column name validation
required_cols <- c("vessel", "trip_id", "date")
missing_cols  <- setdiff(required_cols, names(elog))
if (length(missing_cols) > 0) {
  stop(glue("Elog parquet is missing expected columns: {paste(missing_cols, collapse=', ')}\n",
            "Available columns: {paste(names(elog), collapse=', ')}"))
}

# Resolve trip_id values for the requested vessel and date range
trip_info <- elog %>%
  filter(vessel == setvessel,
         date >= startdate,
         date <= enddate) %>%
  summarise(
    trips      = paste(sort(unique(trip_id)), collapse = "_"),
    ntrips     = n_distinct(trip_id),
    year       = year(min(date, na.rm = TRUE)),
    week       = isoweek(min(date, na.rm = TRUE)),
    startdate  = min(date, na.rm = TRUE),
    enddate    = max(date, na.rm = TRUE),
    .groups    = "drop"
  )

if (trip_info$ntrips == 0) {
  stop(glue(
    "No trips found for vessel {setvessel} between ",
    "{format(startdate, '%d/%m/%Y')} and {format(enddate, '%d/%m/%Y')}\n",
    "Check vessel name (case-sensitive) and date range."
  ))
}

cat(glue("\nFound {trip_info$ntrips} trip(s) for {setvessel}:\n"))
cat(glue("  Period: {format(trip_info$startdate, '%d/%m/%Y')} to {format(trip_info$enddate, '%d/%m/%Y')}\n"))
cat(glue("  Year: {trip_info$year}, ISO week: {trip_info$week}\n"))
cat(glue("  Trip ID(s): {trip_info$trips}\n\n"))

# ==========================================================================================================
# CREATE DYNAMIC FILENAME AND DIRECTORY
# ==========================================================================================================

output_filename <- glue(
  "FLYSHOOT_{setvessel}_{trip_info$year}W{sprintf('%02d', trip_info$week)}_",
  "{trip_info$ntrips}trip{ifelse(trip_info$ntrips > 1, 's', '')}.docx"
)

output_dir <- file.path(
  output_base_dir,
  as.character(trip_info$year),
  sprintf("W%02d", trip_info$week)
)

if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
  cat(glue("Created directory: {output_dir}\n"))
} else {
  cat(glue("Using existing directory: {output_dir}\n"))
}

output_path <- file.path(output_dir, output_filename)
cat(glue("Output file: {output_filename}\n\n"))

# ==========================================================================================================
# RENDER
# ==========================================================================================================

cat("Rendering report...\n")
cat("-----------------------------------\n")

start_time <- Sys.time()

tryCatch({

  rmarkdown::render(
    input       = rmd_file,
    output_file = output_path,
    params      = list(
      vessel    = setvessel,
      startdate = startdate,
      enddate   = enddate
    ),
    envir       = new.env()
  )

  elapsed   <- round(as.numeric(difftime(Sys.time(), start_time, units = "secs")), 1)
  file_size <- round(file.info(output_path)$size / 1024, 1)

  cat("-----------------------------------\n")
  cat(glue("✓ SUCCESS!\n"))
  cat(glue("  Report:  {output_path}\n"))
  cat(glue("  Time:    {elapsed}s\n"))
  cat(glue("  Size:    {file_size} KB\n"))

  # Open automatically on Windows
  if (.Platform$OS.type == "windows") shell.exec(output_path)

}, error = function(e) {

  cat("-----------------------------------\n")
  cat(glue("✗ ERROR: {e$message}\n\n"))
  cat("Troubleshooting:\n")
  cat(glue("  1. Parquet root:  {flyshoot_root}\n"))
  cat("  2. Verify elog.parquet has columns: vessel, trip_id, date\n")
  cat("  3. Check FLYSHOOT_tripreport_harmonized.Rmd renders without errors\n")
  cat("  4. Ensure all required R packages are installed (arrow, rmarkdown, etc.)\n")

})

# ==========================================================================================================
# SUMMARY
# ==========================================================================================================

cat("\n==========================================\n")
cat("RENDER SUMMARY\n")
cat("==========================================\n")
cat(glue("Vessel:       {setvessel}\n"))
cat(glue("Date range:   {format(startdate, '%d/%m/%Y')} to {format(enddate, '%d/%m/%Y')}\n"))
cat(glue("Trips found:  {trip_info$ntrips} ({trip_info$trips})\n"))
cat(glue("Output file:  {output_filename}\n"))
cat(glue("Output path:  {output_path}\n"))
cat("==========================================\n")
